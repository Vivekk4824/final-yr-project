# VendorMap B.Tech Project Report

This directory is the complete, self-contained LaTeX source for `main.pdf`. It contains
only the report sources, assets used by the report, build configuration, and compiled PDF.
Application source files are not modified by report compilation.

## Edit academic metadata

Update only the bracketed fields in `metadata.tex` after verifying names, identifiers,
guide, department head, and submission date. Technical content is split across `chapters/`,
front matter across `frontmatter/`, and appendices across `appendices/`.

The title and certificate use `figures/institution/kk-wagh-emblem.png`. If the institute
provides a replacement logo, save it at that exact path and keep the filename unchanged.

## Compile

From PowerShell:

```powershell
cd report
latexmk -xelatex -interaction=nonstopmode -halt-on-error main.tex
```

Alternatively, with GNU Make available, run `make`. The report uses XeLaTeX so that the
installed Times New Roman font can be used directly. MiKTeX may ask to install missing
packages on the first build. Re-run latexmk after changing citations, figures, or headings.

## Validate

```powershell
pdfinfo main.pdf
pdftoppm -png -r 120 main.pdf ../tmp/pdfs/report-page
```

Inspect the title page, certificate, contents, lists, all diagrams, wide tables, screenshots,
bibliography, and appendices. Search `main.log` for `Undefined`, `Overfull`, and
`LaTeX Warning`. Run `latexmk -c main.tex` afterward to remove temporary build files while
keeping `main.pdf`.
