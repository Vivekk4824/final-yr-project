# Build Status

- **Final artifact:** `output/Project_Report.pdf`
- **Actual page count:** 50 A4 pages
- **Build command:** `latexmk -xelatex -interaction=nonstopmode -halt-on-error main.tex`
- **Compiler:** MiKTeX XeTeX 0.999997 through latexmk 4.88
- **Compilation result:** Successful; bibliography and cross-references resolved
- **Fatal errors:** None
- **Undefined citations/references:** None
- **Overfull boxes:** None in the final log
- **Remaining non-fatal diagnostics:** Underfull table cells caused by narrow academic tables;
  one harmless TikZ node-border warning. No content crosses page margins in visual review.

## Verification performed

- Rendered all 50 pages to PNG with Poppler and inspected the redesigned architecture,
  DFD, UML, sequence, activity, bibliography, and representative report pages.
- Inspected title, certificate, contents, chapter typography, UML/DFD pages, test-result
  tables, screenshots, Gantt chart, bibliography/end matter, and final appendix.
- Confirmed A4 page size, roman preliminary numbering, Arabic chapter numbering, and the
  requested 35--50 page range.

## Missing inputs and manual confirmation

- Student names and roll numbers supplied by the project team are recorded in `metadata.tex`
  and should receive a final spelling check before submission.
- The project guide is recorded as Rupali Bora and should receive a final spelling check.
- Department head, submission date, signatures, and certificate wording remain explicit
  placeholders requiring institutional confirmation.
- No authoritative field-survey geometry, obstruction survey, live routing record, live Meta
  delivery record, production deployment record, actual cost bill, or real expert-label
  dataset was found.
- The current backend suite is not clean: 177 passed, 21 failed, and 6 setup errors.
- The current frontend suite could not spawn test workers in the restricted environment.
- Re-run both suites in the pinned development environment after reconciling the issues
  documented in Chapters 7 and 9.
