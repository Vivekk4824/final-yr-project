# VendorMap B.Tech Project Report

This directory contains the modular LaTeX report derived from the repository source and
stored evaluation artifacts. `reference/main.pdf` is retained only as the formatting
reference. Application source files are not modified by report compilation.

## Edit academic metadata

Update only the bracketed fields in `metadata.tex` after verifying names, identifiers,
guide, department head, and submission date. Technical content is split across `chapters/`,
front matter across `frontmatter/`, and appendices across `appendices/`.

## Compile

From PowerShell:

```powershell
cd report
latexmk -xelatex -interaction=nonstopmode -halt-on-error main.tex
New-Item -ItemType Directory -Force output | Out-Null
Copy-Item main.pdf output/Project_Report.pdf -Force
```

Alternatively, with GNU Make available, run `make`. The report uses XeLaTeX so that the
installed Times New Roman font can be used directly. MiKTeX may ask to install missing
packages on the first build. Re-run latexmk after changing citations, figures, or headings.

## Validate

```powershell
pdfinfo output/Project_Report.pdf
pdftoppm -png -r 120 output/Project_Report.pdf tmp/report-page
```

Inspect the title page, certificate, contents, lists, all diagrams, wide tables, screenshots,
bibliography, and appendices. Search `main.log` for `Undefined`, `Overfull`, and `LaTeX Warning`.

## Evidence policy

`PROJECT_ANALYSIS.md` records the repository assessment. `REPORT_EVIDENCE.md` maps report
claims to supporting files and classifies their status. Numerical research outputs are
reported only when present in stored artifacts, and the current test run is distinguished
from older acceptance files. Do not add secrets, private vendor data, unverifiable metrics,
or fabricated certificates.
