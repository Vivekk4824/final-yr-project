# Report Evidence Register

| Important Claim | Status | Primary Evidence | Qualification |
|---|---|---|---|
| VendorMap supports separate vendor and officer workspaces | Source-verified | `frontend/src/features/vendor/`, `frontend/src/features/admin/` | Browser artifacts exist; not production-certified |
| Recommendation engine uses weighted MCDA | Source-verified | `backend/mcda_engine.py` | Configured policy, not learned outcome accuracy |
| K-Means selected two environmental clusters | Artifact-verified | `data/model/versions/manual-142-v2/metadata/kmeans/kmeans_run.json` | Internal clustering metrics only |
| Active data has 258 usable references from 308 zones | Artifact-verified | `.../metadata/features/feature_build_metrics.json` | 50 missing references; points are analytical |
| MCDA top result survived 224 perturbation scenarios | Artifact-verified | `reports/recommendation_evaluation/mcda_sensitivity_summary.json` | One documented request context |
| Pilot geometry validates ten slots | Artifact-verified | `reports/pilot_slots/geographic_validation.json` | Site verification and live routing are false |
| Authentication avoids plaintext session/OTP storage | Source-verified | `backend/services/authentication.py`, `backend/repositories/database.py` | Deployment secrets still require secure operations |
| Allocation optimizer is advisory | Source-verified | `backend/allocation_optimizer.py`, operational approval routes | Human decision and transaction remain authoritative |
| Current backend suite is not clean | Test-verified | 2026-10-29 live run: 177 pass, 21 fail, 6 error | Do not substitute older focused acceptance result |
| Frontend unit suite passed | Unsupported in current run | 2026-10-29 `npm test` blocked by EPERM | Re-run outside restricted sandbox |
| Random Forest achieved MAE 0.2474 | Artifact-verified, synthetic | `reports/synthetic_demo/rf_model_comparison.json` | Pipeline demo only; not real-world performance |
| Open-source stack has no evidenced license purchase | Source-verified / estimated | manifests and cost document | License obligations still require review |
| INR 3,500 monthly pilot hosting | Estimated | `docs/COCOMO_II_Cost_Estimation.md` | Budget placeholder, not quote or bill |
| Literature methods and governance context | Literature-derived | `references.bib` entries cited in Chapter 2 | Not repository implementation evidence |
| Student and approval metadata | Needs confirmation | `metadata.tex` placeholders | Must be completed by project team/institute |

## Inline unresolved facts

Bracketed academic fields remain in `metadata.tex`. The certificate states that these fields
must be confirmed. The report explicitly labels field validation, production deployment,
provider delivery, supervised results, and cost estimates so that absence of evidence is not
silently converted into a claim.
