# VendorMap Repository Analysis

## Project understanding

VendorMap is a React/FastAPI decision-support application for authenticated vendor and
municipal-officer workflows. It combines operational request/allocation management with
versioned geospatial feature processing, descriptive K-Means clustering, weighted MCDA,
advisory allocation optimization, pilot-slot geometry, a privacy-aware PWA, and optional
routing, AI-explanation, and Meta WhatsApp adapters.

The inspected repository has separate `frontend`, `backend`, `scripts`, `research`, `data`,
`models`, `reports`, `tests`, and `docs` areas. Secrets in `.env` were not read. Generated
dependencies and caches were excluded from inspection.

## Evidence map

| Report Claim | Supporting File | Relevant Class/Function/Route | Evidence Status |
|---|---|---|---|
| React/Vite role-aware web client | `frontend/src/app/ImplementationApp.jsx`, `frontend/package.json` | application shell; scripts/dependencies | Source-verified |
| FastAPI router/service architecture | `backend/application.py`, `backend/routers/` | app composition and router endpoints | Source-verified |
| Vendor OTP and admin authentication | `backend/routers/auth.py`, `backend/services/authentication.py` | request/verify OTP, login, session, logout | Source-verified |
| Server-side role and ownership enforcement | `backend/core/security.py`, protected routers | session/role dependencies | Source-verified |
| Hashed sessions/OTPs and HMAC phone identities | `backend/repositories/database.py`, `backend/services/authentication.py` | auth table schema and credential handling | Source-verified |
| Operational vendor/request/allocation/audit tables | `backend/repositories/database.py` | `CREATE TABLE` statements and transactions | Source-verified |
| Weighted missing-data-aware MCDA | `backend/mcda_engine.py` | `_calculate_mcda`, `score_candidates`, `rank_candidates` | Source-verified |
| Preference/AHP policy support | `backend/decision_policy.py`, `backend/ahp_calibration.py` | weight derivation and AHP calibration | Source-verified; current expectation drift |
| Advisory mixed-integer allocation planning | `backend/allocation_optimizer.py` | `optimize_allocations`, `optimize_precomputed` | Source-verified |
| 308 zones, 258 usable references | `data/model/versions/manual-142-v2/metadata/features/feature_build_metrics.json` | stored counts and limitations | Artifact-verified |
| 146 scoreable free-zone candidates | `data/model/versions/manual-142-v2/metadata/acceptance.json` | acceptance summary | Artifact-verified |
| K-Means trained on 258 rows; selected K=2 | `data/model/versions/manual-142-v2/metadata/kmeans/kmeans_run.json` | stored run metadata | Artifact-verified |
| MCDA 224-scenario sensitivity result | `reports/recommendation_evaluation/mcda_sensitivity_summary.json` | stored summary | Artifact-verified |
| Ten computationally valid pilot slots | `reports/pilot_slots/geographic_validation.json`, `backend/geo/pilot_geometry.py` | `validate_layout` and stored validation | Source- and artifact-verified; no field test |
| Vendor/officer screenshots are real repository captures | `reports/vendormap/*.png` | browser artifacts | Artifact-verified |
| PWA excludes authenticated/API data from cache | `frontend/src/pwa/sw.js`, `frontend/src/pwa/sw.test.js` | fetch/cache policy | Source-verified |
| Direct WhatsApp Cloud API integration and simulator | `backend/whatsapp/` | webhook, client, conversation service, simulator | Source-verified; provider deployment unverified |
| Current backend suite status | live `python -m pytest -q` run on 2026-10-29 | 177 passed, 21 failed, 6 errors | Test-verified |
| Current frontend suite status | live `npm test` run on 2026-10-29 | worker spawn blocked by EPERM | Environment-blocked |

## Implementation maturity

- **Implemented and verified in source:** role-separated client, API routers/services,
  operational schema, MCDA, optimizer, pilot geometry, PWA policy, optional provider adapters.
- **Implemented with stored analytical evidence:** feature build, K-Means comparison, MCDA
  sensitivity, computational pilot-slot validation.
- **Implemented but currently not regression-clean:** allocation/category fixtures,
  personalization expectations, baseline contracts, some isolated pilot-layout workflows,
  model artifact loading in the current Python environment.
- **Experimental only:** supervised Random Forest and SHAP outputs based on synthetic expert
  judgments; these are not production accuracy evidence.
- **Not verified:** field legality/geometry, site obstructions, real footfall or revenue,
  live Meta/routing delivery, production deployment, load, backup recovery, external security.

## Uncertainties and missing inputs

Student identities, guide, department-head details, signatures, submission date, and official
approval wording are not independently verified outside the formatting reference. Field
survey files, authoritative legal boundaries, production bills, actual effort logs, live
provider test records, real expert labels, and longitudinal outcome data are absent. The
current environment has dependency and fixture drift, so stored earlier acceptance summaries
must not be represented as the current complete-suite result.
